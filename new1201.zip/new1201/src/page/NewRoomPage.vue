<template>
    <GuideBar />
    <h1>新建房间</h1>
</template>

<script>
import GuideBar from '../components/GuideBar.vue';
export default{
    name:'NewRoomPage',
    components:{
        GuideBar,
    }
}
</script>
